/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gambar;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
/**
 *
 * @author RIFALDI
 */
public class plos extends JPanel {
    private Image img;
    public plos(){
        img = new ImageIcon(getClass().getResource("/gambar/plos.jpg")).getImage();
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        Graphics2D gd = (Graphics2D)g.create();
        gd.drawImage(img,0,0,getWidth(),getHeight(),null);
        gd.dispose();
    }
}
