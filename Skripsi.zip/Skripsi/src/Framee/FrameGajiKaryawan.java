/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Framee;

import Koneksi.koneksi;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Arofah Tours
 */
public class FrameGajiKaryawan extends javax.swing.JFrame {
   public String id,nama,jabatan;
   public int absensi,lembur,uangtransport,bpjs;
   int totalLembur,total_potongan,total_gaji;
    koneksi konek = new koneksi ();
    Statement stmt ;
    ResultSet rs;
    ResultSetMetaData meta;
    Date date = new Date();
    SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy");

    /**
     * Creates new form FrameGajiKaryawan
     */
    public FrameGajiKaryawan() {
        initComponents();
        refreshTable();
        txt_tgl.setText(dateFormat.format(date));
    }
    public void refreshTable() {
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from penggajian order by id_karyawan asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"periode","id karyawan", "nama karyawan", "jabatan", "absensi","lembur", "gaji_pokok", "uang_transport", "gaji_kotor","bonus", "bpjs", "potongan_absensi","total_gaji"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
         Object dataTable[][] = new Object[brs][col];
         int x = 0;
         rs.beforeFirst();
         while (rs.next()) {
             dataTable[x][0] = rs.getString("periode");
             dataTable[x][1] = rs.getString("id_karyawan");
             dataTable[x][2] = rs.getString("nama_karyawan");
             dataTable[x][3] = rs.getString("jabatan");
             dataTable[x][4] = rs.getString("absensi");
             dataTable[x][5] = rs.getString("lembur");
             dataTable[x][6] = rs.getString("gaji_pokok");
             dataTable[x][7] = rs.getString("uang_transport");
             dataTable[x][8] = rs.getString("gaji_kotor");
             dataTable[x][9] = rs.getString("bonus");
             dataTable[x][10] = rs.getString("bpjs");
             dataTable[x][11] = rs.getString("potongan_absensi");
             dataTable[x][12] = rs.getString("total_gaji");
             x++;
         }
         tabel_gaji.setModel(new DefaultTableModel(dataTable, Header));
         stmtTable.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
     public void saveData() {
        try {
            konek.config();
            stmt = konek.conn.createStatement();
            String sql1 = "insert into penggajian(periode,id_karyawan,nama_karyawan,jabatan,absensi,lembur,gaji_pokok,uang_transport,gaji_kotor,bonus,bpjs,potongan_absensi,total_gaji) values('"
                    + txt_tgl.getText() + "','" + txt_id.getText() + "','" + txt_nama.getText() + "','" + txt_jabatan.getText() + "','" +txt_absen.getText() + "','" + totalLembur+ "','" + txt_gajipokok.getText()+ "','" +txt_transport.getText()+ "','" +txt_gajikotor.getText()+ "','" +txt_bonus.getText()+ "','" +txt_bpjs.getText()+ "','" +txt_potonganabsen.getText()+ "','" +txt_totalgaji.getText() + "')";
            stmt.executeUpdate(sql1);
            stmt.close();
            JOptionPane.showMessageDialog(null, "Tambah Data Gaji Karyawan Berhasil ");
            refreshTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void deleteData(){
        try{
            DefaultTableModel model = (DefaultTableModel) tabel_gaji.getModel();
            int row = tabel_gaji.getSelectedRow();
            if(row >= 0){
                int ok=JOptionPane.showConfirmDialog(null, "Anda Yakin ingin di Hapus?","Hapus Data",JOptionPane.YES_NO_OPTION);
                if(ok == 0){
                    konek.config();
                    stmt = konek.conn.createStatement();
                    String sqlmasuk = "delete from penggajian where id_karyawan = '"+((String)model.getValueAt(row,1))+"' ";
                    stmt.executeUpdate(sqlmasuk);
                    
                }
            }
            refreshTable();
            ClearData();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void ClearData () {
        txt_id.setText("");
        txt_nama.setText("");
        txt_jabatan.setText("");
        txt_absen.setText("");
        txt_lembur.setText("");
        txt_transport.setText("");
        txt_bpjs.setText("");
        txt_gajipokok.setText("");
        txt_gajikotor.setText("");
        txt_bonus.setText("");
        txt_potonganabsen.setText("");
        txt_totalgaji.setText("");
        
    }
    public void popup(){
        txt_id.setText(id);
        txt_nama.setText(nama);
        txt_jabatan.setText(jabatan);
        txt_absen.setText(String.valueOf(absensi));
        txt_lembur.setText(String.valueOf(lembur));
        txt_transport.setText(String.valueOf(uangtransport));
        txt_bpjs.setText(String.valueOf(bpjs));
        setGajiPokok();
        setLembur(txt_lembur.getText());
        setGajiKotor();
        setPotongan(txt_absen.getText());
        txt_potonganabsen.setText(String.valueOf(total_potongan));
        txt_bonus.requestFocus();
    }
    
    void setGajiPokok(){
        switch(txt_jabatan.getText()){
            case "Akuntan":
                txt_gajipokok.setText("5000000");
                break;
            case "Direktur Keuangan":
                txt_gajipokok.setText("15000000");
                break;
            case "Direktur Marketing":
                txt_gajipokok.setText("13000000");
                break;
            case "Direktur Utama":
                txt_gajipokok.setText("20000000");
                break;   
            case "Divisi Marketing":
                txt_gajipokok.setText("4200000");
                break;
            case "Divisi Operasional":
                txt_gajipokok.setText("4200000");
                break;
            case "Divisi Pajak":
                txt_gajipokok.setText("4200000");
                break;    
            case "Divisi Tiket":
                txt_gajipokok.setText("4200000");
                break;
            case "General Manager":
                txt_gajipokok.setText("10000000");
                break; 
            case "Kepala Kantor":
                txt_gajipokok.setText("7000000");
                break;
            case "Pembimbing Ibadah":
                txt_gajipokok.setText("3800000");
                break;
            case "Petugas Kesehatan":
                txt_gajipokok.setText("4000000");
                break;    
            default:
                txt_gajipokok.setText("0");
        }
    }
    void setGajiKotor(){
        int a = Integer.parseInt(txt_gajipokok.getText());
        int b = Integer.parseInt(txt_transport.getText());
        int c = a+b+totalLembur;
        txt_gajikotor.setText(String.valueOf(c));
    }
    Integer setLembur(String lembur){
        return totalLembur = Integer.parseInt(lembur)*50000;
    }
    Integer setPotongan(String absen){
        int tempAbsen = 20-Integer.parseInt(absen);
        total_potongan = tempAbsen*150000;
        return total_potongan;
    }
    Integer totalGaji(String gajikotor,String bonus, String bpjs, int potongan){
        return total_gaji = Integer.parseInt(gajikotor) + Integer.parseInt(bonus) - Integer.parseInt(bpjs) - potongan;
    }
    
    void cetakSlipGaji(){
        int row = tabel_gaji.getSelectedRow();
        try {
            konek.config();
            JasperDesign jasperDesign = JRXmlLoader.load("src/Report/SlipGaji.jrxml");
            String sql = "select*from penggajian where id_karyawan = '"+tabel_gaji.getValueAt(row, 1)+"' ";
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasperDesign.setQuery(newQuery);
            JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, konek.conn);
            JasperViewer.viewReport(jasperPrint, false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bg1 = new gambar.bg();
        logo1 = new gambar.Logo();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txt_id = new javax.swing.JTextField();
        txt_nama = new javax.swing.JTextField();
        txt_absen = new javax.swing.JTextField();
        txt_lembur = new javax.swing.JTextField();
        txt_transport = new javax.swing.JTextField();
        txt_gajipokok = new javax.swing.JTextField();
        txt_bpjs = new javax.swing.JTextField();
        txt_totalgaji = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_gaji = new javax.swing.JTable();
        btn_save = new javax.swing.JButton();
        btn_hapus = new javax.swing.JButton();
        btn_keluar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txt_potonganabsen = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txt_gajikotor = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txt_jabatan = new javax.swing.JTextField();
        find = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txt_bonus = new javax.swing.JTextField();
        txt_tgl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout logo1Layout = new javax.swing.GroupLayout(logo1);
        logo1.setLayout(logo1Layout);
        logo1Layout.setHorizontalGroup(
            logo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        logo1Layout.setVerticalGroup(
            logo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel1.setText("Id Karyawan");

        jLabel2.setText("Nama Karyawan");

        jLabel3.setText("Absensi");

        jLabel4.setText("Lembur");

        jLabel5.setText("Gaji Pokok");

        jLabel6.setText("Uang Transport");

        jLabel7.setText("BPJS");

        jLabel8.setText("Total Gaji");

        txt_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_idActionPerformed(evt);
            }
        });

        txt_nama.setEditable(false);

        txt_absen.setEditable(false);

        txt_lembur.setEditable(false);

        txt_transport.setEditable(false);
        txt_transport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_transportActionPerformed(evt);
            }
        });

        txt_gajipokok.setEditable(false);

        txt_bpjs.setEditable(false);

        txt_totalgaji.setEditable(false);

        tabel_gaji.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Periode", "Id Karyawan", "Nama Karyawan", "Jabatan", "Absensi", "Lembur", "Gaji Pokok", "Uang Transport", "BPJS", "Total Gaji", "Potongan Absensi", "Gaji Kotor"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabel_gaji.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_gajiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel_gaji);

        btn_save.setText("Simpan");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        btn_keluar.setText("Keluar");

        jLabel9.setText("Potongan Absensi");

        txt_potonganabsen.setEditable(false);
        txt_potonganabsen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_potonganabsenActionPerformed(evt);
            }
        });

        jLabel10.setText("Gaji Kotor");

        txt_gajikotor.setEditable(false);

        jLabel11.setText("Jabatan");

        txt_jabatan.setEditable(false);

        find.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/find.png"))); // NOI18N
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });

        jButton1.setText("Cetak");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel12.setText("Bonus");

        txt_bonus.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_bonusKeyReleased(evt);
            }
        });

        txt_tgl.setText("Periode");

        javax.swing.GroupLayout bg1Layout = new javax.swing.GroupLayout(bg1);
        bg1.setLayout(bg1Layout);
        bg1Layout.setHorizontalGroup(
            bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bg1Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                            .addComponent(txt_tgl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(261, 261, 261)
                        .addComponent(logo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel2))
                                .addGap(30, 30, 30)
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_jabatan, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_absen, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(find, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(bg1Layout.createSequentialGroup()
                                                .addGap(4, 4, 4)
                                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel7)
                                                    .addComponent(jLabel10)
                                                    .addComponent(jLabel8)
                                                    .addComponent(jLabel12)))
                                            .addGroup(bg1Layout.createSequentialGroup()
                                                .addGap(8, 8, 8)
                                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel4)
                                                    .addComponent(jLabel5)
                                                    .addComponent(jLabel6))))
                                        .addGap(25, 25, 25))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(18, 18, 18)))
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_lembur, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .addComponent(txt_bpjs, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .addComponent(txt_gajikotor, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .addComponent(txt_transport, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .addComponent(txt_gajipokok, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .addComponent(txt_potonganabsen, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .addComponent(txt_totalgaji, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .addComponent(txt_bonus))))
                        .addGap(100, 100, 100)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addComponent(btn_save)
                                .addGap(35, 35, 35)
                                .addComponent(btn_hapus)
                                .addGap(26, 26, 26)
                                .addComponent(btn_keluar)
                                .addGap(31, 31, 31)
                                .addComponent(jButton1)))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        bg1Layout.setVerticalGroup(
            bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bg1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addComponent(logo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                        .addComponent(txt_tgl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(find)
                            .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(txt_jabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txt_absen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_lembur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(6, 6, 6)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txt_gajipokok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txt_transport, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txt_gajikotor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_save)
                            .addComponent(btn_hapus)
                            .addComponent(btn_keluar)
                            .addComponent(jButton1))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txt_bonus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_bpjs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))))
                .addGap(18, 18, 18)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_potonganabsen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txt_totalgaji, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_idActionPerformed

    private void txt_potonganabsenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_potonganabsenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_potonganabsenActionPerformed

    private void txt_transportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_transportActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_transportActionPerformed

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
        PopupGajiKaryawan pak = new PopupGajiKaryawan();
        pak.setVisible(true);
        pak.GajiKaryawan = this;
    }//GEN-LAST:event_findActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        // TODO add your handling code here:
        saveData();
        PopupSlipGaji gaji = new PopupSlipGaji();
        gaji.frameGajiKaryawan = this;
        gaji.setVisible(true);
        gaji.setResizable(false);
        gaji.tempid = txt_id.getText();
        ClearData();
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:
        deleteData();
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void tabel_gajiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_gajiMouseClicked
        // TODO add your handling code here:
        int row = tabel_gaji.getSelectedRow();
                                                 

    }//GEN-LAST:event_tabel_gajiMouseClicked

    private void txt_bonusKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_bonusKeyReleased
        // TODO add your handling code here:
        totalGaji(txt_gajikotor.getText(),txt_bonus.getText(), txt_bpjs.getText(),total_potongan);
        txt_totalgaji.setText(String.valueOf(total_gaji));
    }//GEN-LAST:event_txt_bonusKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        cetakSlipGaji();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameGajiKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameGajiKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameGajiKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameGajiKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameGajiKaryawan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private gambar.bg bg1;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_keluar;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton find;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private gambar.Logo logo1;
    private javax.swing.JTable tabel_gaji;
    private javax.swing.JTextField txt_absen;
    private javax.swing.JTextField txt_bonus;
    private javax.swing.JTextField txt_bpjs;
    private javax.swing.JTextField txt_gajikotor;
    private javax.swing.JTextField txt_gajipokok;
    private javax.swing.JTextField txt_id;
    private javax.swing.JTextField txt_jabatan;
    private javax.swing.JTextField txt_lembur;
    private javax.swing.JTextField txt_nama;
    private javax.swing.JTextField txt_potonganabsen;
    private javax.swing.JLabel txt_tgl;
    private javax.swing.JTextField txt_totalgaji;
    private javax.swing.JTextField txt_transport;
    // End of variables declaration//GEN-END:variables

   
}
