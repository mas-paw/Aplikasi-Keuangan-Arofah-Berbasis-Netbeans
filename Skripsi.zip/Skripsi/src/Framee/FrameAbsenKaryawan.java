/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Framee;

import Koneksi.koneksi;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Arofah Tours
 */
public class FrameAbsenKaryawan extends javax.swing.JFrame {
    public String id,nama,jabatan;
    koneksi konek = new koneksi ();
    Statement stmt ;
    ResultSet rs;
    ResultSetMetaData meta;
    /**
     * Creates new form FrameAbsenKaryawan
     */
    public FrameAbsenKaryawan() {
        initComponents();
        refreshTable();
    }
    public void ClearData () {
        txt_nama.setText("");
        txt_id.setText("");
        txt_jabatan.setText("");
        txt_absen.setText("");
        txt_lembur.setText("");
        txt_transport.setText("");
        txt_bpjs.setText("");
        
    }
    public void refreshTable() {
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from dabsen order by id_karyawan asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"Id Karyawan", "Nama Karyawan", "Jabatan", "Absensi","Lembur", "Uang Transport", "BPJS"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
         Object dataTable[][] = new Object[brs][col];
         int x = 0;
         rs.beforeFirst();
         while (rs.next()) {
             dataTable[x][0] = rs.getString("id_karyawan");
             dataTable[x][1] = rs.getString("nama_karyawan");
             dataTable[x][2] = rs.getString("jabatan");
             dataTable[x][3] = rs.getString("absensi");
             dataTable[x][4] = rs.getString("lembur");
             dataTable[x][5] = rs.getString("uang_transport");
             dataTable[x][6] = rs.getString("bpjs");
             x++;
         }
         tabel_absen.setModel(new DefaultTableModel(dataTable, Header));
         stmtTable.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    public void saveData() {
        try {
            konek.config();
            stmt = konek.conn.createStatement();
            String sql1 = "insert into dabsen(id_karyawan,nama_karyawan,jabatan,absensi,lembur,uang_transport,bpjs) values('"
                    + txt_id.getText() + "','" + txt_nama.getText() + "','" + txt_jabatan.getText() + "','" +txt_absen.getText() + "','" + txt_lembur.getText() + "','" + txt_transport.getText() + "','" + txt_bpjs.getText()+ "')";
            stmt.executeUpdate(sql1);
            stmt.close();
            JOptionPane.showMessageDialog(null, "Tambah Data Absen Karyawan Berhasil ");
            refreshTable();
            ClearData();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void edit(){
    try{
            konek = new koneksi();
            konek.config();
            stmt = konek.conn.createStatement();
            String sql = "update dabsen set absensi='"+txt_absen.getText()+"',lembur='"+txt_lembur.getText()+"',uang_transport='"+txt_transport.getText()+"',bpjs='"+txt_bpjs.getText()+"' where id_karyawan='"+txt_id.getText()+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Edit Data Berhasil ");
            refreshTable();
            ClearData();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }public void deleteData(){
        try{
            DefaultTableModel model = (DefaultTableModel) tabel_absen.getModel();
            int row = tabel_absen.getSelectedRow();
            if(row >= 0){
                int ok=JOptionPane.showConfirmDialog(null, "Anda Yakin ingin di Hapus?","Hapus Data",JOptionPane.YES_NO_OPTION);
                if(ok == 0){
                    konek.config();
                    stmt = konek.conn.createStatement();
                    String sqlmasuk = "delete from dabsen where id_karyawan = '"+((String)model.getValueAt(row,0))+"' ";
                    stmt.executeUpdate(sqlmasuk);
                    
                }
            }
            refreshTable();
            ClearData();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void validasi(){
        if(txt_id.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Masukkan Id Karyawan");
        }else if(txt_nama.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Masukkan Nama Karyawan");
        }else if (txt_jabatan.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan Jabatan");
        }else if (txt_absen.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan Absensi"); 
        }else if (txt_lembur.getText()==null) {
            JOptionPane.showMessageDialog(null, "Masukkan Lembur");
        }else if (txt_transport.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan Uang Transport");
        }else if (txt_bpjs.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan BPJS");
        }else {
            saveData();
        }
    }
         
    public void popup(){
        txt_id.setText(id);
        txt_nama.setText(nama);
        txt_jabatan.setText(jabatan);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bg1 = new gambar.bg();
        logo1 = new gambar.Logo();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_id = new javax.swing.JTextField();
        txt_nama = new javax.swing.JTextField();
        txt_absen = new javax.swing.JTextField();
        txt_lembur = new javax.swing.JTextField();
        txt_transport = new javax.swing.JTextField();
        txt_bpjs = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_absen = new javax.swing.JTable();
        simpan = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        keluar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txt_jabatan = new javax.swing.JTextField();
        find = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout logo1Layout = new javax.swing.GroupLayout(logo1);
        logo1.setLayout(logo1Layout);
        logo1Layout.setHorizontalGroup(
            logo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        logo1Layout.setVerticalGroup(
            logo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel1.setText("Id Karyawan");

        jLabel2.setText("Nama Karyawan");

        jLabel3.setText("Absensi");

        jLabel4.setText("Lembur");

        jLabel5.setText("Uang Transport");

        jLabel6.setText("BPJS");

        txt_nama.setEditable(false);

        txt_transport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_transportActionPerformed(evt);
            }
        });

        txt_bpjs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_bpjsActionPerformed(evt);
            }
        });

        tabel_absen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id Karyawan", "Nama Karyawan", "Jabatan", "Absensi", "Lembur", "Uang Transport", "BPJS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabel_absen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_absenMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel_absen);

        simpan.setText("Simpan");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });

        edit.setText("Edit");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        hapus.setText("Hapus");
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });

        keluar.setText("Keluar");

        jLabel7.setText("Jabatan");

        txt_jabatan.setEditable(false);

        find.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/find.png"))); // NOI18N
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });

        jLabel8.setText("/Jam");

        javax.swing.GroupLayout bg1Layout = new javax.swing.GroupLayout(bg1);
        bg1.setLayout(bg1Layout);
        bg1Layout.setHorizontalGroup(
            bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bg1Layout.createSequentialGroup()
                .addContainerGap(161, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 649, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(162, 162, 162))
            .addGroup(bg1Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGap(272, 272, 272)
                        .addComponent(logo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addGap(32, 32, 32)
                                        .addComponent(simpan)
                                        .addGap(70, 70, 70)
                                        .addComponent(edit))
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(bg1Layout.createSequentialGroup()
                                                .addGap(25, 25, 25)
                                                .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(txt_jabatan)
                                                    .addComponent(txt_nama, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(find, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jLabel7))
                        .addGap(43, 43, 43)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addComponent(txt_lembur, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel8))
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txt_transport, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
                                            .addComponent(txt_bpjs)))
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(txt_absen, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addGap(80, 80, 80)
                                .addComponent(hapus)
                                .addGap(221, 221, 221)
                                .addComponent(keluar)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bg1Layout.setVerticalGroup(
            bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bg1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addComponent(logo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 49, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_absen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)))
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_lembur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(find)
                        .addComponent(jLabel8)))
                .addGap(28, 28, 28)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_transport, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_bpjs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(txt_jabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(simpan)
                    .addComponent(edit)
                    .addComponent(hapus)
                    .addComponent(keluar)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bg1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
        validasi();
    }//GEN-LAST:event_simpanActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
        edit();
    }//GEN-LAST:event_editActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
        deleteData();
    }//GEN-LAST:event_hapusActionPerformed

    private void txt_bpjsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_bpjsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_bpjsActionPerformed

    private void txt_transportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_transportActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_transportActionPerformed

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
        PopupKaryawan pk = new PopupKaryawan();
        pk.setVisible(true);
        pk.absenKaryawan = this;
    }//GEN-LAST:event_findActionPerformed

    private void tabel_absenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_absenMouseClicked
        // TODO add your handling code here:
       int row = tabel_absen.getSelectedRow();
        txt_id.setText((String)tabel_absen.getValueAt(row, 0));
        txt_nama.setText((String)tabel_absen.getValueAt(row, 1));
        txt_jabatan.setText((String)tabel_absen.getValueAt(row, 2));
        txt_absen.setText((String)tabel_absen.getValueAt(row,3));
        txt_lembur.setText((String)tabel_absen.getValueAt(row, 4));
        txt_transport.setText((String)tabel_absen.getValueAt(row, 5));
        txt_bpjs.setText((String)tabel_absen.getValueAt(row, 6));
    }//GEN-LAST:event_tabel_absenMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameAbsenKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameAbsenKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameAbsenKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameAbsenKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameAbsenKaryawan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private gambar.bg bg1;
    private javax.swing.JButton edit;
    private javax.swing.JButton find;
    private javax.swing.JButton hapus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton keluar;
    private gambar.Logo logo1;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tabel_absen;
    private javax.swing.JTextField txt_absen;
    private javax.swing.JTextField txt_bpjs;
    private javax.swing.JTextField txt_id;
    private javax.swing.JTextField txt_jabatan;
    private javax.swing.JTextField txt_lembur;
    private javax.swing.JTextField txt_nama;
    private javax.swing.JTextField txt_transport;
    // End of variables declaration//GEN-END:variables
}
