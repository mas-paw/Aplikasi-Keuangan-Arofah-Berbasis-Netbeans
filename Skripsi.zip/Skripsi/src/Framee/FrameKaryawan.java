/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Framee;

import Koneksi.koneksi;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Arofah Tours
 */
public class FrameKaryawan extends javax.swing.JFrame {

    koneksi konek = new koneksi ();
    Statement stmt ;
    ResultSet rs;
    ResultSetMetaData meta;
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    /**
     * Creates new form FrameKaryawan
     */
    public FrameKaryawan() {
        initComponents();
        refreshTable();
        tgl_lahir.setDateFormatString("yyyy-MM-dd");
    }
    
    public void ClearData () {
        nama_kar.setText("");
        id_kar.setText("");
        no_tlp.setText("");
        tempat_lahir.setText("");
        tgl_lahir.setDate(null);
        buttonGroup1.clearSelection();
        alamat.setText("");
        agama.setText("");
        jabatan.setSelectedIndex(0);
        email.setText("");
        
    }
    
    public void refreshTable() {
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from karyawan order by id_karyawan asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"Nama karyawan", "Id karyawan", "No. Telepon", "Tempat Lahir","Tanggal Lahir", "Jenis Kelamin", "Alamat", "Agama", "Jabatan", "Email"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
         Object dataTable[][] = new Object[brs][col];
         int x = 0;
         rs.beforeFirst();
         while (rs.next()) {
             dataTable[x][0] = rs.getString("nama_karyawan");
             dataTable[x][1] = rs.getString("id_karyawan");
             dataTable[x][2] = rs.getString("no_telepon");
             dataTable[x][3] = rs.getString("tempat_lahir");
             dataTable[x][4] = rs.getString("tanggal_lahir");
             dataTable[x][5] = rs.getString("jenis_kelamin");
             dataTable[x][6] = rs.getString("alamat");
             dataTable[x][7] = rs.getString("agama");
             dataTable[x][8] = rs.getString("jabatan");
             dataTable[x][9] = rs.getString("email");
             x++;
         }
         tabel_karyawan.setModel(new DefaultTableModel(dataTable, Header));
         stmtTable.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    public void saveData() {
        String ttl,jeniskelamin;
        if(laki.isSelected()){
            jeniskelamin = laki.getText();
        }else{
            jeniskelamin = perempuan.getText();
        }
        try {
            konek.config();
            stmt = konek.conn.createStatement();
            String sql1 = "insert into karyawan(nama_karyawan,id_karyawan,no_telepon,tempat_lahir,tanggal_lahir,jenis_kelamin,alamat,agama,jabatan,email) values('"
                    + nama_kar.getText() + "','" + id_kar.getText() + "','" + no_tlp.getText() + "','" +tempat_lahir.getText() + "','" + dateFormat.format(tgl_lahir.getDate()) + "','" + jeniskelamin+ "','" + alamat.getText() + "','" + agama.getText() + "','" + jabatan.getSelectedItem()+ "','" + email.getText() + "')";
            stmt.executeUpdate(sql1);
            stmt.close();
            JOptionPane.showMessageDialog(null, "Tambah Data Karyawan Berhasil ");
            refreshTable();
            ClearData();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void edit(){
        String ttl,jeniskelamin;
        if(laki.isSelected()){
            jeniskelamin = laki.getText();
        }else{
            jeniskelamin = perempuan.getText();
        }
        try{
            konek = new koneksi();
            konek.config();
            stmt = konek.conn.createStatement();
            String sql = "update karyawan set nama_karyawan='"+nama_kar.getText()+"',no_telepon='"+no_tlp.getText()+"',tempat_lahir='"+tempat_lahir.getText()+"',tanggal_lahir='"+dateFormat.format(tgl_lahir.getDate())+"',jenis_kelamin='"+jeniskelamin+"',alamat='"+alamat.getText()+"',agama='"+agama.getText()+"',jabatan='"+jabatan.getSelectedItem()+"',email='"+email.getText()+"' where id_karyawan='"+id_kar.getText()+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Edit Data Berhasil ");
            refreshTable();
            ClearData();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void deleteData(){
        try{
            DefaultTableModel model = (DefaultTableModel) tabel_karyawan.getModel();
            int row = tabel_karyawan.getSelectedRow();
            if(row >= 0){
                int ok=JOptionPane.showConfirmDialog(null, "Anda Yakin ingin di Hapus?","Hapus Data",JOptionPane.YES_NO_OPTION);
                if(ok == 0){
                    konek.config();
                    stmt = konek.conn.createStatement();
                    String sqlmasuk = "delete from karyawan where id_karyawan = '"+((String)model.getValueAt(row,1))+"' ";
                    stmt.executeUpdate(sqlmasuk);
                    
                }
            }
            refreshTable();
            ClearData();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void validasi(){
        if(nama_kar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Masukkan Nama Karyawan");
        }else if(id_kar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Masukkan Id Karyawan");
        }else if (no_tlp.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan No.Telepon");
        }else if (tempat_lahir.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan Tempat Lahir"); 
        }else if (tgl_lahir.getDate()==null) {
            JOptionPane.showMessageDialog(null, "Masukkan Tanggal Lahir");
        }else if (!(laki.isSelected() || perempuan.isSelected())){
            JOptionPane.showMessageDialog(null, "Masukkan Jenis Kelamin");
        }else if (alamat.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan Alamat Karyawan");
        }else if (agama.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan Agama");
        }else if (jabatan.getSelectedIndex()==0) {
            JOptionPane.showMessageDialog(null, "Pilih Jabatan");
        }else if (email.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan Email");
        }else {
            saveData();
        }
    }
    public void search(){
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from karyawan WHERE id_karyawan LIKE '%"+cari.getText()+"%' OR nama_karyawan LIKE '%"+cari.getText()+"%' OR no_telepon LIKE '%"+cari.getText()+"%' OR tempat_lahir LIKE '%"+cari.getText()+"%' OR tanggal_lahir LIKE '%"+cari.getText()+"%'OR jenis_kelamin LIKE '%"+cari.getText()+"%'OR alamat LIKE '%"+cari.getText()+"%' OR agama LIKE '%"+cari.getText()+"%' OR jabatan LIKE '%"+cari.getText()+"%' OR email LIKE '%"+cari.getText()+"%' ";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"Nama karyawan", "Id karyawan", "No. Telepon", "Tempat Lahir","Tanggal Lahir", "Jenis Kelamin", "Alamat", "Agama", "Jabatan", "Email"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0] = rs.getString("nama_karyawan");
                dataTable[x][1] = rs.getString("id_karyawan");
                dataTable[x][2] = rs.getString("no_telepon");
                dataTable[x][3] = rs.getString("tempat_lahir");
                dataTable[x][4] = rs.getString("tanggal_lahir");
                dataTable[x][5] = rs.getString("jenis_kelamin");
                dataTable[x][6] = rs.getString("alamat");
                dataTable[x][7] = rs.getString("agama");
                dataTable[x][8] = rs.getString("jabatan");
                dataTable[x][9] = rs.getString("email");
                x++;
            }
            tabel_karyawan.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        bg1 = new gambar.bg();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        logo1 = new gambar.Logo();
        nama_kar = new javax.swing.JTextField();
        id_kar = new javax.swing.JTextField();
        no_tlp = new javax.swing.JTextField();
        tempat_lahir = new javax.swing.JTextField();
        agama = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        laki = new javax.swing.JRadioButton();
        perempuan = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        alamat = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabel_karyawan = new javax.swing.JTable();
        btn_simpan = new javax.swing.JButton();
        btn_edit = new javax.swing.JButton();
        btn_hapus = new javax.swing.JButton();
        btn_keluar = new javax.swing.JButton();
        tgl_lahir = new com.toedter.calendar.JDateChooser();
        jLabel11 = new javax.swing.JLabel();
        cari = new javax.swing.JTextField();
        jabatan = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.FlowLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("DATA KARYAWAN");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("Nama Karyawan");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Id Karyawan");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("No. Telepon");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Tempat Tanggal Lahir");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Jenis Kelamin");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("Agama");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Jabatan");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Email");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("Alamat");

        javax.swing.GroupLayout logo1Layout = new javax.swing.GroupLayout(logo1);
        logo1.setLayout(logo1Layout);
        logo1Layout.setHorizontalGroup(
            logo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 152, Short.MAX_VALUE)
        );
        logo1Layout.setVerticalGroup(
            logo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 92, Short.MAX_VALUE)
        );

        id_kar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_karActionPerformed(evt);
            }
        });

        no_tlp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                no_tlpActionPerformed(evt);
            }
        });

        buttonGroup1.add(laki);
        laki.setText("Laki - Laki");
        laki.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lakiActionPerformed(evt);
            }
        });

        buttonGroup1.add(perempuan);
        perempuan.setText("Perempuan");

        alamat.setColumns(20);
        alamat.setRows(5);
        jScrollPane1.setViewportView(alamat);

        tabel_karyawan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nama Karyawan", "Id Karyawan", "No. Telepon", "Tempat  Lahir", "Tanggal Lahir", "Jenis Kelamin", "Alamat", "Agama", "Jabatan", "Email"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, false, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabel_karyawan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_karyawanMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabel_karyawan);

        btn_simpan.setText("Simpan");
        btn_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpanActionPerformed(evt);
            }
        });

        btn_edit.setText("Edit");
        btn_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editActionPerformed(evt);
            }
        });

        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        btn_keluar.setText("Keluar");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setText("CARI");

        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });
        cari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cariKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cariKeyTyped(evt);
            }
        });

        jabatan.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jabatan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Jabatan", "Akuntan", "Direktur Keuangan", "Direktur Marketing", "Direktur Utama", "Divisi Marketing", "Divisi Operasional", "Divisi Pajak", "Divisi Tiket", "General Manager", "Kepala Kantor", "Pembimbing Ibadah", "Petugas Kesehatan" }));

        javax.swing.GroupLayout bg1Layout = new javax.swing.GroupLayout(bg1);
        bg1.setLayout(bg1Layout);
        bg1Layout.setHorizontalGroup(
            bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addComponent(tempat_lahir, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tgl_lahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                                .addComponent(laki, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(perempuan, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1)
                            .addComponent(no_tlp)
                            .addComponent(id_kar)
                            .addComponent(nama_kar, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cari, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addGap(171, 171, 171)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(bg1Layout.createSequentialGroup()
                                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(9, 9, 9))
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(agama, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                            .addComponent(email)
                            .addComponent(jabatan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGap(171, 171, 171)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addComponent(btn_simpan)
                                .addGap(66, 66, 66)
                                .addComponent(btn_edit)
                                .addGap(63, 63, 63)
                                .addComponent(btn_hapus)
                                .addGap(69, 69, 69)
                                .addComponent(btn_keluar))))
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(logo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bg1Layout.setVerticalGroup(
            bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                            .addGroup(bg1Layout.createSequentialGroup()
                                .addComponent(cari)
                                .addGap(2, 2, 2))))
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(logo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(35, 35, 35)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nama_kar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(agama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(id_kar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9)
                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(no_tlp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bg1Layout.createSequentialGroup()
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(tempat_lahir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tgl_lahir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(laki)
                            .addComponent(perempuan))
                        .addGap(18, 18, 18)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bg1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(bg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_simpan)
                            .addComponent(btn_edit)
                            .addComponent(btn_hapus)
                            .addComponent(btn_keluar))))
                .addContainerGap(57, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bg1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        getContentPane().add(jPanel1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lakiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lakiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lakiActionPerformed

    private void no_tlpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_no_tlpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_no_tlpActionPerformed

    private void id_karActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_karActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_id_karActionPerformed

    private void btn_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpanActionPerformed
        // TODO add your handling code here:
        validasi();
    }//GEN-LAST:event_btn_simpanActionPerformed

    private void btn_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editActionPerformed
        // TODO add your handling code here:
        edit();
    }//GEN-LAST:event_btn_editActionPerformed

    private void tabel_karyawanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_karyawanMouseClicked
        // TODO add your handling code here
        try{
            String jeniskelamin,tgl;
            JTable table = (JTable)evt.getSource();
            int row = table.getSelectedRow();
            tgl = table.getValueAt(row, 4).toString();
            Date tgl_asli = null;
            tgl_asli = new SimpleDateFormat("yyyy-MM-dd").parse(tgl);
            if("Laki - Laki".equals(table.getValueAt(row, 5))){
                laki.setSelected(true);
            }else{
                perempuan.setSelected(true);
            }
            nama_kar.setText((String)table.getValueAt(row, 0));
            id_kar.setText((String)table.getValueAt(row, 1));
            no_tlp.setText((String)table.getValueAt(row, 2));
            tempat_lahir.setText((String)table.getValueAt(row,3));
            tgl_lahir.setDate(tgl_asli);
            alamat.   setText((String)table.getValueAt(row, 6));
            agama.   setText((String)table.getValueAt(row, 7));
            jabatan.   setSelectedItem((String)table.getValueAt(row, 8));
            email.   setText((String)table.getValueAt(row, 9));
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_tabel_karyawanMouseClicked

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:
        deleteData();
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cariActionPerformed

    private void cariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cariKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_cariKeyTyped

    private void cariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cariKeyReleased
        // TODO add your handling code here:
        search();
    }//GEN-LAST:event_cariKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameKaryawan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField agama;
    private javax.swing.JTextArea alamat;
    private gambar.bg bg1;
    private javax.swing.JButton btn_edit;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_keluar;
    private javax.swing.JButton btn_simpan;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField cari;
    private javax.swing.JTextField email;
    private javax.swing.JTextField id_kar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox<String> jabatan;
    private javax.swing.JRadioButton laki;
    private gambar.Logo logo1;
    private javax.swing.JTextField nama_kar;
    private javax.swing.JTextField no_tlp;
    private javax.swing.JRadioButton perempuan;
    private javax.swing.JTable tabel_karyawan;
    private javax.swing.JTextField tempat_lahir;
    private com.toedter.calendar.JDateChooser tgl_lahir;
    // End of variables declaration//GEN-END:variables
}
